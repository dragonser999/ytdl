Run
```
cd RaganorkDOWN
```
```
ssh-keygen
```
verify with gitub
```
bash run.sh
```
